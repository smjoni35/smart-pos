'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import AuthShell from '@/components/AuthShell';

const TYPES = [
  ['grocery', 'মুদি দোকান'],
  ['supershop', 'সুপারশপ'],
  ['library', 'লাইব্রেরি / বই-খাতা'],
  ['pharmacy', 'ফার্মেসি'],
  ['electronics', 'ইলেকট্রনিক্স'],
  ['clothing', 'কাপড় / জুতা'],
  ['general', 'অন্যান্য'],
];

export default function RegisterShopPage() {
  const router = useRouter();
  const supabase = createClient();
  const [shopName, setShopName] = useState('');
  const [type, setType] = useState('grocery');
  const [fullName, setFullName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const { error } = await supabase.rpc('register_shop', {
      p_shop_name: shopName.trim(),
      p_business_type: type,
      p_full_name: fullName.trim(),
    });
    setLoading(false);
    if (error) {
      if (error.message.includes('Already registered')) {
        router.push('/dashboard');
        router.refresh();
        return;
      }
      return setError('দোকান তৈরি করা যায়নি: ' + error.message);
    }
    router.push('/dashboard');
    router.refresh();
  }

  return (
    <AuthShell title="আপনার দোকান তৈরি করুন" subtitle="মাত্র তিনটি তথ্য দিন">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">দোকানের নাম</label>
          <input
            required
            value={shopName}
            onChange={(e) => setShopName(e.target.value)}
            className="w-full border rounded-xl px-3.5 py-3 outline-none focus:ring-4 focus:ring-emerald-500/15"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">ব্যবসার ধরন</label>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="w-full border rounded-xl px-3.5 py-3 bg-white outline-none focus:ring-4 focus:ring-emerald-500/15"
          >
            {TYPES.map(([v, label]) => (
              <option key={v} value={v}>
                {label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">মালিকের নাম</label>
          <input
            required
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            className="w-full border rounded-xl px-3.5 py-3 outline-none focus:ring-4 focus:ring-emerald-500/15"
          />
        </div>

        {error && (
          <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
            {error}
          </p>
        )}

        <button
          disabled={loading}
          className="w-full bg-emerald-600 text-white rounded-xl py-3 font-semibold disabled:opacity-60"
        >
          {loading ? 'তৈরি হচ্ছে...' : 'দোকান তৈরি করুন'}
        </button>
      </form>
    </AuthShell>
  );
}
