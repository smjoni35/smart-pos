'use client';

import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import Icon from '@/components/Icon';

export default function SignOutButton() {
  const router = useRouter();
  async function signOut() {
    await createClient().auth.signOut();
    router.push('/login');
    router.refresh();
  }
  return (
    <button
      onClick={signOut}
      className="flex items-center gap-1.5 text-sm text-white/80 hover:text-white hover:bg-white/10 rounded-lg px-2.5 py-2"
    >
      <Icon name="logout" size={16} />
      লগআউট
    </button>
  );
}
