'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Icon from '@/components/Icon';

// [লিংক, নাম, আইকন, কে দেখবে: null = সবাই, 'mgr' = মালিক/ম্যানেজার, 'owner' = শুধু মালিক]
const ITEMS = [
  ['/dashboard', 'হোম', 'home', null],
  ['/dashboard/pos', 'বিক্রি (POS)', 'pos', null],
  ['/dashboard/sales', 'বিক্রির তালিকা', 'sales', null],
  ['/dashboard/products', 'পণ্য', 'box', null],
  ['/dashboard/categories', 'ক্যাটাগরি', 'tag', null],
  ['/dashboard/customers', 'কাস্টমার ও বাকি', 'users', null],
  ['/dashboard/purchases', 'মাল কেনা', 'bag', 'mgr'],
  ['/dashboard/suppliers', 'সাপ্লায়ার', 'truck', 'mgr'],
  ['/dashboard/expenses', 'খরচ', 'wallet', 'mgr'],
  ['/dashboard/adjustments', 'নষ্ট মাল', 'trash', 'mgr'],
  ['/dashboard/reports', 'রিপোর্ট', 'chart', 'mgr'],
  ['/dashboard/staff', 'স্টাফ', 'staff', 'owner'],
  ['/dashboard/settings', 'সেটিংস', 'settings', 'owner'],
];

// সুপার অ্যাডমিনের কোনো দোকান নেই, তাই আলাদা মেনু
const ADMIN_ITEMS = [['/dashboard/admin', 'সব দোকান', 'shield']];

function visible(level, role) {
  if (!level) return true;
  if (level === 'mgr') return ['owner', 'manager'].includes(role);
  if (level === 'owner') return role === 'owner';
  return false;
}

export default function Nav({ role }) {
  const path = usePathname();
  const items =
    role === 'super_admin'
      ? ADMIN_ITEMS
      : ITEMS.filter(([, , , level]) => visible(level, role));
  return (
    <nav className="nav-bar overflow-x-auto no-print">
      <div className="max-w-5xl mx-auto px-3 py-2 flex gap-1.5 whitespace-nowrap">
        {items.map(([href, label, icon]) => {
          const active = href === '/dashboard' ? path === href : path.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={`flex items-center gap-1.5 px-3.5 py-2 text-sm rounded-full ${
                active
                  ? 'bg-emerald-700 text-white font-medium shadow'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Icon name={icon} size={16} />
              {label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
