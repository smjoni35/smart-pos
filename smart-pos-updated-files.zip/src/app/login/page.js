'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import AuthShell from '@/components/AuthShell';
import Icon from '@/components/Icon';

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  const [mode, setMode] = useState('login'); // 'login' | 'signup'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setInfo('');
    setLoading(true);

    if (mode === 'login') {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) return setError('ইমেইল বা পাসওয়ার্ড ভুল হয়েছে');
      router.push('/dashboard');
      router.refresh();
    } else {
      if (password.length < 6) {
        setLoading(false);
        return setError('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে');
      }
      const { data, error } = await supabase.auth.signUp({ email, password });
      setLoading(false);
      if (error) return setError(error.message);
      if (data.session) {
        router.push('/register-shop');
        router.refresh();
      } else {
        setInfo('আপনার ইমেইলে একটি নিশ্চিতকরণ লিংক পাঠানো হয়েছে। লিংকে ক্লিক করে তারপর লগইন করুন।');
      }
    }
  }

  return (
    <AuthShell
      title={mode === 'login' ? 'স্বাগতম' : 'নতুন অ্যাকাউন্ট'}
      subtitle={mode === 'login' ? 'আপনার দোকানে লগইন করুন' : 'নতুন অ্যাকাউন্ট খুলুন'}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">ইমেইল</label>
          <input
            type="email"
            required
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full border rounded-xl px-3.5 py-3 outline-none focus:ring-4 focus:ring-emerald-500/15"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">পাসওয়ার্ড</label>
          <div className="relative">
            <input
              type={show ? 'text' : 'password'}
              required
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border rounded-xl pl-3.5 pr-11 py-3 outline-none focus:ring-4 focus:ring-emerald-500/15"
            />
            <button
              type="button"
              onClick={() => setShow(!show)}
              aria-label={show ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 w-9 h-9 grid place-items-center rounded-lg text-slate-400 hover:text-slate-700"
            >
              <Icon name={show ? 'eyeOff' : 'eye'} size={18} />
            </button>
          </div>
        </div>

        {error && (
          <p className="text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
            {error}
          </p>
        )}
        {info && (
          <p className="text-sm text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">
            {info}
          </p>
        )}

        <button
          disabled={loading}
          className="w-full bg-emerald-600 text-white rounded-xl py-3 font-semibold disabled:opacity-60"
        >
          {loading ? 'অপেক্ষা করুন...' : mode === 'login' ? 'লগইন' : 'অ্যাকাউন্ট খুলুন'}
        </button>
      </form>

      <button
        type="button"
        onClick={() => {
          setMode(mode === 'login' ? 'signup' : 'login');
          setError('');
          setInfo('');
        }}
        className="w-full text-center text-sm font-medium text-emerald-700 mt-5 py-1"
      >
        {mode === 'login' ? 'নতুন? অ্যাকাউন্ট খুলুন' : 'আগে থেকেই অ্যাকাউন্ট আছে? লগইন করুন'}
      </button>
    </AuthShell>
  );
}
