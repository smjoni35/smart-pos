import Icon from './Icon';

const POINTS = [
  ['pos', 'দ্রুত বিক্রি ও রসিদ'],
  ['box', 'স্টক ও দাম এক জায়গায়'],
  ['users', 'কাস্টমারের বাকির খাতা'],
];

// লগইন ও দোকান-রেজিস্ট্রেশনের কমন ডিজাইন
export default function AuthShell({ title, subtitle, children }) {
  return (
    <main className="min-h-screen md:grid md:grid-cols-2">
      <section className="auth-hero text-white relative overflow-hidden px-6 pt-10 pb-20 md:p-12 md:flex md:flex-col md:justify-between">
        <svg
          className="absolute -right-24 -top-24 opacity-[0.14] pointer-events-none"
          width="360"
          height="360"
          viewBox="0 0 360 360"
          fill="none"
          aria-hidden="true"
        >
          <circle cx="180" cy="180" r="170" stroke="#E3BE72" strokeWidth="1.5" />
          <circle cx="180" cy="180" r="125" stroke="#E3BE72" strokeWidth="1.5" />
          <circle cx="180" cy="180" r="80" stroke="#E3BE72" strokeWidth="1.5" />
        </svg>

        <div className="relative flex items-center gap-3">
          <span className="logo-mark">
            <Icon name="cart" size={20} />
          </span>
          <span className="text-lg font-semibold tracking-wide">POS</span>
        </div>

        <div className="relative mt-8 md:mt-0 max-w-md">
          <h2 className="text-3xl md:text-4xl font-bold leading-tight">
            দোকানের পুরো হিসাব, এক জায়গায়
          </h2>
          <p className="mt-3 text-white/70 md:text-lg">
            বিক্রি, স্টক, বাকি ও লাভ-ক্ষতি — সবকিছু ফোন থেকেই সামলান।
          </p>
        </div>

        <ul className="relative hidden md:block space-y-3 text-white/85">
          {POINTS.map(([icon, text]) => (
            <li key={text} className="flex items-center gap-3">
              <span className="w-9 h-9 rounded-xl bg-white/10 grid place-items-center text-amber-200">
                <Icon name={icon} size={18} />
              </span>
              {text}
            </li>
          ))}
        </ul>
      </section>

      <section className="px-4 -mt-10 pb-10 md:mt-0 md:pb-0 md:flex md:items-center md:justify-center md:p-12 relative">
        <div className="w-full max-w-sm mx-auto bg-white rounded-2xl shadow-lg p-6">
          <h1 className="text-xl font-bold">{title}</h1>
          <p className="text-slate-500 text-sm mt-1 mb-6">{subtitle}</p>
          {children}
        </div>
      </section>
    </main>
  );
}
