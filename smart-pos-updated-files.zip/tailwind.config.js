/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: [
          '"Anek Bangla"',
          '"Hind Siliguri"',
          '"Noto Sans Bengali"',
          'system-ui',
          '-apple-system',
          '"Segoe UI"',
          'sans-serif',
        ],
      },
      // পুরো অ্যাপের emerald → গাঢ় টিল (deep teal) ব্র্যান্ড রং
      colors: {
        emerald: {
          50: '#EEF6F4',
          100: '#D6EBE6',
          200: '#AED6CD',
          300: '#7DBBAE',
          400: '#4A9C8D',
          500: '#2A8073',
          600: '#1B6B5F',
          700: '#14564D',
          800: '#0F433D',
          900: '#0B322E',
          950: '#072320',
        },
        // amber → ব্রাস/সোনালি অ্যাকসেন্ট
        amber: {
          50: '#FBF6EA',
          100: '#F5E9C8',
          200: '#EBD59A',
          300: '#E0BD6C',
          400: '#D3A64A',
          500: '#C08F2E',
          600: '#A67A22',
          700: '#845E1A',
          800: '#6A4B16',
          900: '#4F3711',
        },
        slate: {
          50: '#F6F8F8',
          100: '#EDF1F1',
          200: '#DFE6E5',
          300: '#C6D1CF',
          400: '#8A9B98',
          500: '#62736F',
          600: '#4A5B58',
          700: '#35433F',
          800: '#1F2B29',
          900: '#121B1A',
        },
      },
      borderColor: { DEFAULT: '#E1E8E6' },
      borderRadius: {
        lg: '0.75rem',
        xl: '1rem',
        '2xl': '1.375rem',
      },
      boxShadow: {
        DEFAULT: '0 1px 2px rgba(15,46,44,.05), 0 10px 28px -14px rgba(15,46,44,.22)',
        lg: '0 2px 4px rgba(15,46,44,.06), 0 18px 40px -16px rgba(15,46,44,.35)',
      },
    },
  },
  plugins: [],
};
